# Droplet model tables

The five CSV files under `Data_S1/` accompany Supplementary Text 1. `data_catalog.csv` gives their paths, row counts and column names.

- `fusion_verified.csv` contains adaptive-quadrature results for 180 radii at three potentials. `legacy_fusion.csv` contains midpoint results. Rates of contact are formal model outputs. Very small rates are reported on a logarithmic scale.
- `state_grid.csv` contains the 12,106 composition points retained by the historical floating-point grid filter. The states are classifications under assumed thresholds. `state_threshold_sensitivity.csv` varies those thresholds.
- `interface_budget.csv` tabulates required molecular fractions at selected diameters. The full-coverage and charge-budget criteria have different prefactors.

The repository's `droplet_analysis/` directory contains the R model and figure scripts. From the repository root run `Rscript --vanilla figure_reproduction/figures.R figure_reproduction` to draw the five supplementary figures.
