# Membrane model tables

The files under `Data_S2/` accompany Supplementary Text 2. `data_catalog.csv` gives the path, row count and columns of each CSV. JSON files record simulation settings and summaries.

| Tables | Interpretation |
| --- | --- |
| `diameter`, `convergence`, `cohesive_grid`, `ensemble` | Fig. S3. Each row is a retained finite-element solution. Read the force residual (pN) alongside the optimizer flag. |
| `lipid_replicates`, `bootstrap_verified` | Fig. S4. Twenty-four trajectory means at six radii and 20,000 within-radius resamples. The ZIP contains summary statistics for each trajectory. |
| `phase_boundaries`, `competing_risk`, `selected_probability_curves` | Fig. S5. The reported probability is `two_stage_pore_probability_before_wrap`. Empty first-crossing values indicate branches without that crossing. |
| `legacy_threshold_*` | Geometric threshold summaries under an assumed 100 ± 10 nm constraint. |
| `postpore_*/history.csv`, `postpore_verified.csv` | Table S8. Closure is the elapsed simulation time of the first zero pore radius after the peak. Particle strain denotes the maximum absolute normal-strain component. |

The three profile collections in `kinetic_inputs/` supply the stored kinetics inputs. They are separate from the intact finite-element results in Fig. S3. The legacy `probability_definition` in `kinetic_metadata.json` describes a one-stage diagnostic. Some historical JSON settings contain bare NaN for unused values and require a reader that accepts this extension.

For figure reproduction from a repository checkout, run `Rscript --vanilla figure_reproduction/figures.R figure_reproduction` at the repository root. Simulation source code and raw lipid force trajectories are outside this data archive.
