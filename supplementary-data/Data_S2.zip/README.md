# Reproducibility package for Supplementary Texts 1 and 2

This package supports reanalysis of saved calculations and regeneration of five figures. It is not a new set of experimental measurements. The archived models are separate computational components. In particular, `pre_rupture_fem` fields are not the input geometry of `unified_membrane_model` kinetics.

## Contents and figure mapping

| Supplement | Files relative to this directory | Use |
|---|---|---|
| Text 1; Fig. S1 | `data/drop/legacy_fusion.csv`, `fusion_verified.csv` | Archived midpoint results and independent adaptive integration; radius in µm, diameter in nm, energies in kBT, rates in s^-1 or their base-10 logarithms |
| Text 1; Fig. S2 | `data/drop/state_grid.csv`, `state_threshold_sensitivity.csv`, `interface_budget.csv` | Dimensionless design grid, simultaneous threshold sensitivity and molecule-count budgets; no measured phase boundary or window half-width |
| Text 2; Fig. S3 | `data/membrane/diameter.csv`, `convergence.csv`, `cohesive_grid.csv`, `ensemble.csv` | 3,838 distinct retained intact-FEM configurations; center and spatial-maximum tension in pN/nm; force residual in pN |
| Text 2; Fig. S4 | `data/membrane/lipid_summary.json`, `lipid_replicates.csv`, `bootstrap_verified.csv` | 24 independent trajectory means and 20,000 within-radius bootstrap fits; force and line tension in pN |
| Text 2; Fig. S5 | `data/membrane/phase_boundaries.csv`, `competing_risk.csv`, `selected_probability_curves.csv` | 336 conditional kinetic parameter combinations; use `two_stage_pore_probability_before_wrap` for the reported three-state observable |
| Text 2; kinetics | `data/membrane/kinetic_inputs/`, `wrapping_trajectory.csv`, `kinetic_metadata.json` | Three upstream profile/shape collections, kinetic clock and stored parameter grid |
| Text 2; distinct legacy calibration | `data/membrane/legacy_threshold_*.csv` | Importance-weighted geometric threshold under assumed 100 ± 10 nm Gaussian constraint; not a measured likelihood or MCMC |
| Text 2; Table S8 | `data/membrane/postpore_*/` and `postpore_verified.csv` | Two separately parameterized histories; `time_ms` is elapsed time from the run origin; strain is a particle normal-strain component |

`data_catalog.csv` lists every CSV, its row count and its exact column names. `verification.json` records numerical checks. `SHA256SUMS.txt` verifies the packaged files. Source provenance for the author is one directory above this package.

## Reanalyze the reported results

The tested runtime was Python 3.14 with NumPy, SciPy and pandas. Exact installed versions are recorded in `verification.json` and `python_versions.txt`. A CPU runtime is sufficient for this step; no source directories on the original computer are needed.

```sh
python verify_results.py
Rscript figures.R .
```

The Python script recalculates all 540 droplet integrals, the state-grid classifications, 20,000 bootstrap fits, threshold and residual summaries, kinetic classification quantiles and post-pore time summaries. It rewrites derived CSV files and `verification.json` within this directory. It leaves the archived source tables unchanged. The R script needs ggplot2, patchwork, svglite and ragg. It writes PNG, PDF, SVG and 600-dpi TIFF figures. R version information is recorded in `R_session_info.txt`.

Editable Word files can be regenerated from the parent directory with:

```sh
python build_documents.py
```

This step also requires python-docx, lxml, latex2mathml and mathml2omml. The generator includes explicit OMML square-root and empty-limit handling so equations render correctly in Word and LibreOffice. PDF generation uses a separate office renderer, not this Python script.

## Tests and full simulation code

From this directory:

```sh
PYTHONPATH=code python -m unittest discover -s code/pre_rupture_fem/tests -v
PYTHONPATH=code python -m pytest code/unified_membrane_model/tests -q
```

Archived implementations and parameter files are in `code/pre_rupture_fem`, `code/wetting_wrap_fem`, `code/unified_membrane_model`, `code/fem_pore` and `code/lipid_discrete`. Original README files and scripts preserve historical claims and path defaults; the revised Supplementary Texts govern the interpretation of this package. Do not run legacy plotting scripts expecting the revised figures; use `figures.R`.

The three kinetic profile/shape datasets are included. A full kinetic scan can be reconstructed using the supplied command helper:

```sh
python rerun_kinetics.py
```

This runs a computationally expensive simulation into a new `rerun_kinetics` directory. It was not rerun in the present editorial revision. The helper takes all numerical scan values from the archived metadata, selects the stress-based two-stage model and preserves input-directory precedence. The subsequent classification program is included in `code/unified_membrane_model/summarize_competing_kinetics.py`; consult its `--help` for summary-output arguments.

Recreating the 24 lipid trajectories requires OpenMM with an appropriate CUDA environment plus the original model dependencies. Configurations are included under `code/lipid_discrete/configs/pore_line_tension_cuda`. This package contains trajectory summaries, not the 24 original force time series or molecular frames. Consequently, refitting is reproducible from these means, but equilibration and autocorrelation cannot be independently reanalyzed without obtaining or rerunning the trajectories. No GPU simulation or entire 3,838-configuration FEM campaign was rerun here.

## Interpretation of nonstandard values

- Very small contact rates are stored logarithmically to avoid underflow. They are formal HHF extrapolations at the stated low salt, outside a controlled thin-double-layer regime.
- A solver return is not a strict convergence certificate. Retain `converged`, the residual and the lowest-energy selection rule together.
- Missing crossing diameters denote classifications without that crossing; they are not zero-diameter thresholds.
- `kinetic_metadata.json` preserves a legacy `probability_definition` string for a single-stage hazard diagnostic. The actual reported two-stage observable is explicitly named in the CSV. The unused `defect_line_tension_fractions` field contains a legacy NaN; it is not an estimated physical quantity.
- Bootstrap resamples, parameter-grid points and numerical mesh refinements are not biological replicates.
- The Table S8 closure time is the first zero pore radius after the peak, expressed as absolute simulation elapsed time. It is not the time interval from the pore-radius peak to closure.
